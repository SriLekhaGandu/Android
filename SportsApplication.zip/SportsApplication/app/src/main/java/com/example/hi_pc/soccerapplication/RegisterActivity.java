package com.example.hi_pc.soccerapplication;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    Button registerButton, cancelButton;
    EditText userNameText, passwordText, confPasswordText;
    String userName, pass, confPassword;
    private FirebaseAuth auth;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        registerButton = (Button) findViewById(R.id.register_button);
        userNameText = (EditText) findViewById(R.id.register_user_name);
        passwordText = (EditText) findViewById(R.id.register_password);
        confPasswordText = (EditText) findViewById(R.id.register_confirm_password);
        cancelButton = (Button) findViewById(R.id.register_reset);
        auth = FirebaseAuth.getInstance();
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userName = userNameText.getText().toString();
                pass = passwordText.getText().toString();
                confPassword = confPasswordText.getText().toString();
                if (!userName.isEmpty()) {
                    if (!pass.isEmpty()) {
                        if (pass.equals(confPassword)) {
                            if (checkOnline()) {
                                addToFirebase();
                            } else {
                                Toast.makeText(RegisterActivity.this, getResources().getString(R.string.No_Internet), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            passwordText.setError(getString(R.string.password_didinot_match));
                        }
                    } else {
                        passwordText.setError(getString(R.string.password_required));
                    }
                } else {
                    userNameText.setError(getString(R.string.username_required));
                }
            }
        });
    }

    public boolean checkOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null)
            return true;
        else
            return false;
    }

    private void addToFirebase() {
        auth.createUserWithEmailAndPassword(userName, pass)
                .addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(RegisterActivity.this, getResources().getString(R.string.Auth_Failed) + task.getException(),
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                            finish();
                        }
                    }
                });
    }

    public void gotoLogin(View view) {
        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
        finish();
        startActivity(intent);
    }

    public void resetForm(View view) {
        confPasswordText.setText("");
        userNameText.setText("");
        passwordText.setText("");
    }
}
