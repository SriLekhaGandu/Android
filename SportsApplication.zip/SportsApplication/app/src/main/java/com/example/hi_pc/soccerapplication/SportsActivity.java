package com.example.hi_pc.soccerapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SportsActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    @BindView(R.id.default_text)
    TextView tv;
    Snackbar snackbar;
    String value = "";
    int position;
    LinearLayoutManager linearLayoutManager;
    public static final String POS = "pos";
    public static final String KEY = "myKey";
    ProgressDialog dialog;
    LinearLayout linearLayout;
    RecyclerView recyclerView;
    ArrayList<LeaguePojo> leaguesPojosList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sports);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getResources().getString(R.string.app_name));
        ButterKnife.bind(this);
        linearLayout = (LinearLayout) findViewById(R.id.sport_snack_bar);
        linearLayoutManager = new LinearLayoutManager(SportsActivity.this);
        recyclerView = (RecyclerView) findViewById(R.id.league_recycler);
        dialog = new ProgressDialog(this);
        recyclerView.setVisibility(View.GONE);
        Bundle bundle = getIntent().getExtras();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        if (checkOnline()) {
            if (!dialog.isShowing()) {
                if (savedInstanceState != null) {
                    if (savedInstanceState.containsKey(KEY))
                        value = savedInstanceState.getString(KEY);
                    if (!value.isEmpty()) {
                        leaguesPojosList = new ArrayList<LeaguePojo>();

                        tv.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);
                        linearLayoutManager = new LinearLayoutManager(SportsActivity.this);
                        position = savedInstanceState.getInt(POS);
                        LeagueAsyncTask leagueAsyncTask = new LeagueAsyncTask(savedInstanceState.getString(KEY));
                        leagueAsyncTask.execute();
                    }
                }
            }
        } else
            setSnackBar();
    }

    private void retry() {
        Intent intent = new Intent(SportsActivity.this, SportsActivity.class);
        finish();
        startActivity(intent);
    }

    public boolean checkOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null)
            return true;
        else
            return false;
    }

    public void setSnackBar() {
        snackbar = Snackbar.make(linearLayout, getResources().getString(R.string.NoInternet), Snackbar.LENGTH_INDEFINITE)
                .setAction(getResources().getString(R.string.RETRY), new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        retry();
                    }
                });
        snackbar.setActionTextColor(Color.RED);
        View view = snackbar.getView();
        TextView tv = (TextView) view.findViewById(android.support.design.R.id.snackbar_text);
        tv.setTextColor(Color.YELLOW);
        snackbar.show();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        tv.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);
        if (id == R.id.nav_cricket) {
            if (checkOnline()) {
                value = String.valueOf(item.getTitle());
                LeagueAsyncTask leagueAsyncTask = new LeagueAsyncTask(item.getTitle().toString());
                leagueAsyncTask.execute();
            } else {
                setSnackBar();
            }
        } else if (id == R.id.nav_basketball) {
            if (checkOnline()) {
                value = String.valueOf(item.getTitle());
                LeagueAsyncTask leagueAsyncTask = new LeagueAsyncTask(item.getTitle().toString());
                leagueAsyncTask.execute();
            } else {
                setSnackBar();
            }
        } else if (id == R.id.nav_motor_sport) {
            if (checkOnline()) {
                value = String.valueOf(item.getTitle());

                LeagueAsyncTask leagueAsyncTask = new LeagueAsyncTask(item.getTitle().toString());
                leagueAsyncTask.execute();
            } else {
                setSnackBar();
            }
        } else if (id == R.id.nav_soccer) {
            value = String.valueOf(item.getTitle());

            if (checkOnline()) {
                LeagueAsyncTask leagueAsyncTask = new LeagueAsyncTask(item.getTitle().toString());
                leagueAsyncTask.execute();
            } else {
                setSnackBar();
            }
        } else if (id == R.id.nav_wrestling) {
            value = String.valueOf(item.getTitle());

            if (checkOnline()) {
                LeagueAsyncTask leagueAsyncTask = new LeagueAsyncTask(item.getTitle().toString());
                leagueAsyncTask.execute();
            } else {
                setSnackBar();
            }
        } else if (id == R.id.nav_fav) {
            value = String.valueOf(item.getTitle());

            Intent intent = new Intent(SportsActivity.this, TeamsDisplayActivity.class);
            intent.putExtra(getResources().getString(R.string.fav), true);
            startActivity(intent);
        } else if (id == R.id.nav_logout) {
            if (checkOnline()) {
                Intent intent = new Intent(SportsActivity.this, LoginActivity.class);
                SharedPreferences sharedPreferences = getSharedPreferences("MyPref", 0);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean(getResources().getString(R.string.LOGGED), false);
                editor.apply();
                finish();
                startActivity(intent);
            } else {
                Toast.makeText(SportsActivity.this, getResources().getString(R.string.No_Internet), Toast.LENGTH_SHORT).show();
            }
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (!dialog.isShowing()) {
            if (!value.isEmpty())
                outState.putString(KEY, value);
            position = linearLayoutManager.findFirstVisibleItemPosition();
            outState.putInt(POS, position);
        }
    }

    public class LeagueAsyncTask extends AsyncTask<String, Void, String> {
        String leagueString;

        public LeagueAsyncTask(String s) {
            this.leagueString = s;
        }

        @Override
        protected void onPreExecute() {
            dialog.setMessage("Loading Data Please Wait");
            dialog.show();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
            recyclerView.setLayoutManager(linearLayoutManager);
            recyclerView.setAdapter(new LeagueDisplayAdapter(SportsActivity.this, leaguesPojosList));
            recyclerView.scrollToPosition(position);
        }

        @Override
        protected String doInBackground(String... strings) {

            URL leagueUrl = null;
            String poster_response = "";
            GetDetailsURL connect = new GetDetailsURL();
            try {
                leagueUrl = connect.buildUrl(getResources().getString(R.string.leagueUrl));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            String leagueResponse = null;
            int i = 0;
            leagueResponse = connect.getDetailsResponse(leagueUrl);
            leaguesPojosList = new ArrayList<LeaguePojo>();
            try {
                JSONObject leagueObject = new JSONObject(leagueResponse);
                JSONArray leagueArray = leagueObject.getJSONArray(getResources().getString(R.string.leagues));
                while (i < leagueArray.length()) {
                    JSONObject league = leagueArray.getJSONObject(i);
                    String name = league.getString(getResources().getString(R.string.leagueName));
                    String id = league.getString(getResources().getString(R.string.leagueId));
                    String sport = league.getString(getResources().getString(R.string.leagueSport));
                    if (leagueString.equals(sport)) {
                        LeaguePojo leaguesPojo = new LeaguePojo(name, id, sport);
                        leaguesPojosList.add(leaguesPojo);
                    }
                    i++;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return poster_response;
        }
    }
}
