package com.example.hi_pc.soccerapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class LeagueDisplayAdapter extends RecyclerView.Adapter<LeagueDisplayAdapter.LeagueDataHolder> {
    public void setLeagueData(ArrayList<LeaguePojo> leagueData) {
        this.leagueData = leagueData;
    }

    ArrayList<LeaguePojo> leagueData;
    Context mContext;

    public LeagueDisplayAdapter(SportsActivity sportsActivity, ArrayList<LeaguePojo> leagueData) {
        this.leagueData = leagueData;
        this.mContext = sportsActivity;
    }

    @Override
    public LeagueDisplayAdapter.LeagueDataHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        int id = R.layout.league;
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View leagueView = inflater.inflate(id, parent, false);
        LeagueDisplayAdapter.LeagueDataHolder leagueDataHolder = new LeagueDisplayAdapter.LeagueDataHolder(leagueView);
        return leagueDataHolder;
    }

    @Override
    public void onBindViewHolder(LeagueDataHolder holder, int position) {
        if (position % 2 != 0)
            holder.cardView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.lightviolet));
        else
            holder.cardView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.cement));
        holder.leagueName.setText(leagueData.get(position).getLeagueName());
    }

    @Override
    public int getItemCount() {
        return leagueData.size();
    }

    public class LeagueDataHolder extends RecyclerView.ViewHolder {
        TextView leagueName;
        CardView cardView;

        public LeagueDataHolder(final View itemView) {
            super(itemView);
            cardView = (CardView) itemView.findViewById(R.id.card_view);
            leagueName = (TextView) itemView.findViewById(R.id.league_name);
            leagueName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(mContext, leagueData.get(getAdapterPosition()).getId(), Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(mContext, TeamsDisplayActivity.class);
                    intent.putExtra(itemView.getResources().getString(R.string.Data), leagueData.get(getAdapterPosition()));
                    intent.putExtra(itemView.getResources().getString(R.string.Position), getAdapterPosition());
                    mContext.startActivity(intent);
                }
            });
        }
    }
}
