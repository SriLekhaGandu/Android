package com.example.hi_pc.soccerapplication;

import android.net.Uri;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class GetDetailsURL {
    public GetDetailsURL() {
    }

    public static URL buildUrl(String teamString) throws MalformedURLException {
        Uri teamUri = Uri.parse(teamString).buildUpon().build();
        URL teamUrl = null;
        teamUrl = new URL(teamUri.toString());
        return teamUrl;
    }

    public String getDetailsResponse(URL url) {
        InputStream inputStream = null;
        StringBuilder stringBuilder = null;
        String teamRespone;
        HttpURLConnection httpURLConnection;
        BufferedReader bufferedReader;
        try {
            httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            teamRespone = null;
            inputStream = new BufferedInputStream(httpURLConnection.getInputStream());
            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            stringBuilder = new StringBuilder();
            String getLine;
            while ((getLine = bufferedReader.readLine()) != null) {
                stringBuilder.append(getLine).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }
}
