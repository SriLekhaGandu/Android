package com.example.hi_pc.movielovers;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ReviewHolder> {
    ArrayList<JSONReview> jsonReview;
    Context context;

    public ReviewAdapter(Context movieDetailsDisplayActivity, ArrayList<JSONReview> jsonReviewList) {
        this.jsonReview = jsonReviewList;
        context = movieDetailsDisplayActivity;
    }

    @Override
    public ReviewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.review_recycler, parent, false);
        return new ReviewAdapter.ReviewHolder(v);
    }

    @Override
    public void onBindViewHolder(ReviewHolder holder, int position) {
        if (jsonReview.size() > 0) {
            holder.author.setText(jsonReview.get(position).getReview_author());
            holder.content.setText(jsonReview.get(position).getReview_content());
            holder.url.setText(jsonReview.get(position).getReview_url());
        }
    }

    @Override
    public int getItemCount() {
        return jsonReview.size();
    }

    public class ReviewHolder extends RecyclerView.ViewHolder {
        TextView content, author, url, rv;

        public ReviewHolder(View itemView) {
            super(itemView);
            content = (TextView) itemView.findViewById(R.id.content);
            author = (TextView) itemView.findViewById(R.id.author);
            url = (TextView) itemView.findViewById(R.id.url);
            rv = (TextView) itemView.findViewById(R.id.rv);
        }
    }
}
