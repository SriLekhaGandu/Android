package com.example.hi_pc.movielovers;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class FavouriteDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "favouriteDatabase.db";
    public static final int DATABASE_VERSION = 1;

    public FavouriteDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void drop(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS MovieDetails");
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String CREATE_TABLE = "CREATE TABLE "
                + FavouriteContract.FavouriteContractEntry.TABLE_NAME + " ( "
                + FavouriteContract.FavouriteContractEntry.COLUMN_BACKDROP_PATH + " TEXT NOT NULL, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_POSTER_PATH + " TEXT NOT NULL, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_TITLE + " TEXT NOT NULL, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_FAVOURITE + " TEXT NOT NULL, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_RATING + " REAL NOT NULL, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_VOTES + " INTEGER NOT NULL, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_RELEASE_DATE + " TEXT NOT NULL, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_LANGUAGE + " TEXT NOT NULL, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_OVERVIEW + " TEXT, "
                + FavouriteContract.FavouriteContractEntry.COLUMN_ID + " TEXT " + ");";
        sqLiteDatabase.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + FavouriteContract.FavouriteContractEntry.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }


}
