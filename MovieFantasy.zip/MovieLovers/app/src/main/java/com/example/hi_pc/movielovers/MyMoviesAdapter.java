package com.example.hi_pc.movielovers;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyMoviesAdapter extends RecyclerView.Adapter<MyMoviesAdapter.MyMoviesHolder> {
    ArrayList<JSONData> jsonMovieData;
    Context mContext;

    public MyMoviesAdapter(MoviesDisplay moviesDisplay, ArrayList<JSONData> jsonMovieData) {
        this.jsonMovieData = jsonMovieData;
        this.mContext = moviesDisplay;
    }

    @Override
    public MyMoviesAdapter.MyMoviesHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        int id = R.layout.my_movies_list;
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View movieView = inflater.inflate(id, parent, false);
        MyMoviesHolder myMoviesHolder = new MyMoviesHolder(movieView);
        return myMoviesHolder;
    }

    @Override
    public void onBindViewHolder(MyMoviesAdapter.MyMoviesHolder holder, int position) {
        Picasso.with(mContext).load(jsonMovieData.get(position).getMovie_poster()).placeholder(R.mipmap.ic_launcher).into(holder.movie_image_view);
    }

    @Override
    public int getItemCount() {
        return jsonMovieData.size();
    }

    public class MyMoviesHolder extends RecyclerView.ViewHolder {
        ImageView movie_image_view;

        public MyMoviesHolder(View itemView) {
            super(itemView);
            movie_image_view = (ImageView) itemView.findViewById(R.id.movie_image_view);
            movie_image_view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent movieIntent = new Intent(mContext, MovieDetailsDisplayActivity.class);
                    movieIntent.putExtra(String.valueOf(R.string.BACKDROP_POSTER), jsonMovieData.get(getAdapterPosition()).getMovie_background_poster());
                    movieIntent.putExtra(String.valueOf(R.string.POSTER_PATH), jsonMovieData.get(getAdapterPosition()).getMovie_poster());
                    movieIntent.putExtra(String.valueOf(R.string.ORIGINAL_TITLE), jsonMovieData.get(getAdapterPosition()).getMovie_title());
                    movieIntent.putExtra(String.valueOf(R.string.VOTE_AVERAGE), jsonMovieData.get(getAdapterPosition()).getMovie_vote_average());
                    movieIntent.putExtra(String.valueOf(R.string.VOTE_COUNT), jsonMovieData.get(getAdapterPosition()).getMovie_votes());
                    movieIntent.putExtra(String.valueOf(R.string.RELEASE_DATE), jsonMovieData.get(getAdapterPosition()).getMovie_release_date());
                    movieIntent.putExtra(String.valueOf(R.string.ORIGINAL_LANGUAGE), jsonMovieData.get(getAdapterPosition()).getMovie_language());
                    movieIntent.putExtra(String.valueOf(R.string.OVERVIEW), jsonMovieData.get(getAdapterPosition()).getMovie_overview());
                    movieIntent.putExtra(String.valueOf(R.string.ID), jsonMovieData.get(getAdapterPosition()).getMovie_id());
                    mContext.startActivity(movieIntent);
                }
            });
        }
    }
}
