package com.example.hi_pc.movielovers;

public class JSONTrailer {
    public String getTrailer_url() {
        return trailer_url;
    }

    public String getTrailer_langugae() {
        return trailer_language;
    }

    public String getTrailer_country() {
        return trailer_country;
    }

    public String getTrailer_key() {
        return trailer_key;
    }

    public String getTrailer_name() {
        return trailer_name;
    }

    public String getTrailer_site() {
        return trailer_site;
    }

    public String getTrailer_id() {
        return trailer_id;
    }

    public long getTrailer_size() {
        return trailer_size;
    }

    public String getTrailer_type() {
        return trailer_type;
    }

    String trailer_url;
    String trailer_language;
    String trailer_country;
    String trailer_key;
    String trailer_name;
    String trailer_id;
    String trailer_site;
    long trailer_size;
    String trailer_type;

    public JSONTrailer(String trailer_url, String trailer_id, String trailer_language, String trailer_country, String trailer_key, String trailer_name, String trailer_site, long trailer_size, String trailer_type) {
        this.trailer_url = trailer_url;
        this.trailer_id = trailer_id;
        this.trailer_language = trailer_language;
        this.trailer_country = trailer_country;
        this.trailer_key = trailer_key;
        this.trailer_name = trailer_name;
        this.trailer_site = trailer_site;
        this.trailer_size = trailer_size;
        this.trailer_type = trailer_type;
    }
}
