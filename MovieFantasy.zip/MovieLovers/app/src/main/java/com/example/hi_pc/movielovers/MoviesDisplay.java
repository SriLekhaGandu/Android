package com.example.hi_pc.movielovers;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.support.design.widget.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import butterknife.BindView;

public class MoviesDisplay extends AppCompatActivity implements LoaderManager.LoaderCallbacks {
    RecyclerView movie_recycler_view;
    ProgressDialog dialog;
    int flag = 0, id;
    Snackbar snackbar;
    String movieString;
    NetworkInfo networkInfo;
    boolean check;
    int scrollPosition = 0;
    Cursor cursor;
    public String key = "myKey";
    public String value = "popular";
    public String position = "position";
    MyMoviesAdapter movie_recycler_adpater;
    ArrayList<JSONData> jsonDataList;
    FavouriteDBHelper dbHelper;
    @BindView(R.id.coordinator)
    LinearLayout linearLayout;
    GridLayoutManager gridLayoutManager;
    private static int i = 0;
    public static final String LINK = "https://api.themoviedb.org/3/movie/";
    public static final String IMAGE = "https://image.tmdb.org/t/p/w300";
    public static final String POPULARMOVIES = "PopularMovies";
    public static final String TOPRATEDMOVIES = "TopRatedMovies";
    public static final String FAVOURITEMOVIES = "FavouriteMovies";

    @Override
    protected void onRestart() {
        Log.i("on","restart");
        if(value==FAVOURITEMOVIES)
        {
            jsonDataList = new ArrayList<JSONData>();
            cursor = getContentResolver().query(FavouriteContract.CONTENT_URI, null, null, null, null);
            while (cursor.moveToNext()) {
                JSONData jsonData = new JSONData(cursor.getInt(9), cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getDouble(4), cursor.getLong(5), cursor.getString(6), cursor.getString(7), cursor.getString(8));
                jsonDataList.add(jsonData);
            }
            cursor.close();
            if (jsonDataList.size() > 0) {
                movie_recycler_adpater = new MyMoviesAdapter(MoviesDisplay.this, jsonDataList);
                gridLayoutManager = new GridLayoutManager(this, 2);
                movie_recycler_view.setLayoutManager(gridLayoutManager);
                movie_recycler_view.setAdapter(movie_recycler_adpater);
            } else {
                AlertDialog.Builder alert = new AlertDialog.Builder(MoviesDisplay.this);
                alert.setMessage(R.string.Message).setTitle(R.string.NoFavourites);
                alert.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        Intent intent = new Intent(MoviesDisplay.this, MoviesDisplay.class);
                        startActivity(intent);
                    }
                });
                AlertDialog dialog = alert.create();
                dialog.show();
            }
        }
        super.onRestart();
    }

    public NetworkInfo checkOnline() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemid = item.getItemId();
        if (itemid == R.id.action_sort_popular) {
            value = POPULARMOVIES;
            scrollPosition = 0;
            jsonDataList = new ArrayList<JSONData>();
            id = 10;
            LinearLayout linearLayout = (LinearLayout) findViewById(R.id.coordinator);
            networkInfo = checkOnline();
            if (networkInfo != null) {
                getSupportLoaderManager().restartLoader(id, null, this);
            } else {
                Snackbar snackbar = Snackbar.make(linearLayout, getResources().getString(R.string.NoInternet), Snackbar.LENGTH_INDEFINITE)
                        .setAction(getResources().getString(R.string.RETRY), new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                retry();
                            }
                        });
                snackbar.setActionTextColor(Color.RED);
                View view = snackbar.getView();
                TextView tv = (TextView) view.findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.YELLOW);
                snackbar.show();
            }
            return true;
        }
        if (itemid == R.id.top_rated) {
            value = TOPRATEDMOVIES;
            scrollPosition = 0;
            jsonDataList = new ArrayList<JSONData>();
            id = 20;
            LinearLayout linearLayout = (LinearLayout) findViewById(R.id.coordinator);
            if (networkInfo != null) {
                getSupportLoaderManager().restartLoader(id, null, this);
            } else {
                Snackbar snackbar = Snackbar.make(linearLayout, R.string.NoInternet, Snackbar.LENGTH_INDEFINITE)
                        .setAction(R.string.RETRY, new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                retry();
                            }
                        });
                snackbar.setActionTextColor(Color.RED);
                View view = snackbar.getView();
                TextView tv = (TextView) view.findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.YELLOW);
                snackbar.show();
            }
            return true;
        }
        if (itemid == R.id.action_sort_favourite) {
            value = FAVOURITEMOVIES;
            scrollPosition = 0;
            if (snackbar != null)
                snackbar.dismiss();
            jsonDataList = new ArrayList<JSONData>();
            cursor = getContentResolver().query(FavouriteContract.CONTENT_URI, null, null, null, null);
            while (cursor.moveToNext()) {
                JSONData jsonData = new JSONData(cursor.getInt(9), cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getDouble(4), cursor.getLong(5), cursor.getString(6), cursor.getString(7), cursor.getString(8));
                jsonDataList.add(jsonData);
            }
            cursor.close();
            if (jsonDataList.size() > 0) {
                movie_recycler_adpater = new MyMoviesAdapter(MoviesDisplay.this, jsonDataList);
                gridLayoutManager = new GridLayoutManager(this, 2);
                movie_recycler_view.setLayoutManager(gridLayoutManager);
                movie_recycler_view.setAdapter(movie_recycler_adpater);
            } else {
                AlertDialog.Builder alert = new AlertDialog.Builder(MoviesDisplay.this);
                alert.setMessage(R.string.Message).setTitle(R.string.NoFavourites);
                alert.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        Intent intent = new Intent(MoviesDisplay.this, MoviesDisplay.class);
                        startActivity(intent);
                    }
                });
                AlertDialog dialog = alert.create();
                dialog.show();
            }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = new MenuInflater(this);
        menuInflater.inflate(R.menu.myoptions, menu);
        return true;
    }

    @Override
    protected void onPause() {
        if (dialog != null) {
            dialog.dismiss();
        }
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(key, value);
        if (!getSupportLoaderManager().hasRunningLoaders()) {
            scrollPosition = gridLayoutManager.findFirstVisibleItemPosition();
            outState.putInt(position, scrollPosition);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("on","create");
        dialog = new ProgressDialog(MoviesDisplay.this);
        setContentView(R.layout.activity_movies_display);
        jsonDataList = new ArrayList<JSONData>();
        movie_recycler_view = (RecyclerView) findViewById(R.id.movie_recycler_view);
        dbHelper = new FavouriteDBHelper(this);
        if (savedInstanceState != null)
            scrollPosition = savedInstanceState.getInt(position);
        id = 10;
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.coordinator);
        networkInfo = checkOnline();
        if (networkInfo != null) {
            if (savedInstanceState != null) {
                value = savedInstanceState.getString(key);
                switch (value) {
                    case POPULARMOVIES:
                        getSupportLoaderManager().restartLoader(10, null, this);
                        break;
                    case TOPRATEDMOVIES:
                        getSupportLoaderManager().restartLoader(20, null, this);
                        break;
                    case FAVOURITEMOVIES:
                        jsonDataList = new ArrayList<JSONData>();
                        cursor = getContentResolver().query(FavouriteContract.CONTENT_URI, null, null, null, null);
                        while (cursor.moveToNext()) {
                            JSONData jsonData = new JSONData(cursor.getInt(9), cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getDouble(4), cursor.getLong(5), cursor.getString(6), cursor.getString(7), cursor.getString(8));
                            jsonDataList.add(jsonData);
                        }
                        cursor.close();
                        if (jsonDataList.size() > 0) {
                            movie_recycler_adpater = new MyMoviesAdapter(MoviesDisplay.this, jsonDataList);
                            gridLayoutManager = new GridLayoutManager(this, 2);
                            movie_recycler_view.setLayoutManager(gridLayoutManager);
                            movie_recycler_view.setAdapter(movie_recycler_adpater);
                        } else {
                            AlertDialog.Builder alert = new AlertDialog.Builder(MoviesDisplay.this);
                            alert.setMessage(R.string.Message).setTitle(R.string.NoFavourites);
                            alert.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    finish();
                                    Intent intent = new Intent(MoviesDisplay.this, MoviesDisplay.class);
                                    startActivity(intent);
                                }
                            });
                            AlertDialog dialog = alert.create();
                            dialog.show();
                        }
                        break;
                    default:
                        getSupportLoaderManager().restartLoader(id, null, this);
                }
            } else
                getSupportLoaderManager().initLoader(id, null, this);

        } else {
            snackbar = Snackbar.make(linearLayout, R.string.NoInternet, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.RETRY, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            retry();
                        }
                    });
            snackbar.setActionTextColor(Color.RED);
            View view = snackbar.getView();
            TextView tv = (TextView) view.findViewById(android.support.design.R.id.snackbar_text);
            tv.setTextColor(Color.YELLOW);
            snackbar.show();
        }
        if (value == FAVOURITEMOVIES) {
            jsonDataList = new ArrayList<JSONData>();
            cursor = getContentResolver().query(FavouriteContract.CONTENT_URI, null, null, null, null);
            while (cursor.moveToNext()) {
                JSONData jsonData = new JSONData(cursor.getInt(9), cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getDouble(4), cursor.getLong(5), cursor.getString(6), cursor.getString(7), cursor.getString(8));
                jsonDataList.add(jsonData);
            }
            cursor.close();
            if (jsonDataList.size() > 0) {
                movie_recycler_adpater = new MyMoviesAdapter(MoviesDisplay.this, jsonDataList);
                movie_recycler_view.setLayoutManager(gridLayoutManager);
                movie_recycler_view.setAdapter(movie_recycler_adpater);
            } else {
                AlertDialog.Builder alert = new AlertDialog.Builder(MoviesDisplay.this);
                alert.setMessage(R.string.Message).setTitle(R.string.NoFavourites);
                alert.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        Intent intent = new Intent(MoviesDisplay.this, MoviesDisplay.class);
                        startActivity(intent);
                    }
                });
                AlertDialog dialog = alert.create();
                dialog.show();
            }
        }
    }


    private void retry() {
        Intent intent = new Intent(MoviesDisplay.this, MoviesDisplay.class);
        finish();
        startActivity(intent);
    }

    @Override
    public Loader onCreateLoader(final int id, Bundle args) {
        return new AsyncTaskLoader<String>(this) {
            @Override
            protected void onStartLoading() {
                dialog = new ProgressDialog(MoviesDisplay.this);
                dialog.setMessage(getResources().getString(R.string.Loading));
                dialog.show();
                forceLoad();
            }

            @Override
            public String loadInBackground() {
                jsonDataList = new ArrayList<JSONData>();
                switch (id) {
                    case 10:
                        movieString = getResources().getString(R.string.POPULAR);
                        break;
                    case 20:
                        movieString = getResources().getString(R.string.TOP_RATED);
                        break;
                }
                String poster_response = "";
                if (movieString != null) {
                    URL movieUrl = null;
                    GetMovieDetailsURL connect = new GetMovieDetailsURL();
                    try {
                        movieUrl = connect.buildMovieUrl(movieString);
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                    String movieResponse;
                    int i = 0;
                    movieResponse = connect.getMovieDetailsResponse(movieUrl);
                    try {
                        JSONObject movieObject = new JSONObject(movieResponse);
                        JSONArray movieArray = movieObject.getJSONArray(getResources().getString(R.string.Results));
                        while (i < movieArray.length()) {
                            JSONObject movie = movieArray.getJSONObject(i);
                            String movie_poster = IMAGE + movie.optString(getResources().getString(R.string.POSTER_PATH));
                            String movie_backdrop_poster = IMAGE + movie.getString(getResources().getString(R.string.BACKDROP_POSTER));
                            String movie_title = movie.optString(getResources().getString(R.string.ORIGINAL_TITLE));

                            double movie_votes_average = movie.getDouble(getResources().getString(R.string.VOTE_AVERAGE));
                            long movie_votes_count = movie.getLong(getResources().getString(R.string.VOTE_COUNT));
                            String movie_release_date = movie.getString(getResources().getString(R.string.RELEASE_DATE));
                            String movie_language = movie.getString(getResources().getString(R.string.ORIGINAL_LANGUAGE));
                            String movie_overview = movie.getString(getResources().getString(R.string.OVERVIEW));
                            int movie_id = movie.getInt(getResources().getString(R.string.ID));
                            JSONData jsonData = new JSONData(movie_id, movie_backdrop_poster, movie_poster, movie_title, movie_votes_average, movie_votes_count, movie_release_date, movie_language, movie_overview);
                            poster_response = jsonData.getMovie_poster();
                            jsonDataList.add(jsonData);
                            i++;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                return poster_response;
            }
        };
    }

    @Override
    public void onLoadFinished(Loader loader, Object data) {
        if (dialog.isShowing()) {
            dialog.dismiss();
        }
        movie_recycler_adpater = new MyMoviesAdapter(MoviesDisplay.this, jsonDataList);
        gridLayoutManager = new GridLayoutManager(MoviesDisplay.this, 2);
        movie_recycler_view.setLayoutManager(gridLayoutManager);
        movie_recycler_view.setAdapter(movie_recycler_adpater);
        movie_recycler_view.scrollToPosition(scrollPosition);
    }

    @Override
    public void onLoaderReset(Loader loader) {
        if (dialog.isShowing()) {
            dialog.dismiss();
        }
        loader.forceLoad();
    }
}
