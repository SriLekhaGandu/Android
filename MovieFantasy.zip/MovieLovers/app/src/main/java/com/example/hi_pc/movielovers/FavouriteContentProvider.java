package com.example.hi_pc.movielovers;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

public class FavouriteContentProvider extends ContentProvider {
    private FavouriteDBHelper favouriteDBHelper = new FavouriteDBHelper(getContext());
    private static final UriMatcher myuri = matchUri();
    SQLiteDatabase sqLiteDatabase;

    public FavouriteContentProvider() {
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int match = myuri.match(uri);
        long result;
        if (match == FavouriteContract.ROW_ID) {
            SQLiteDatabase sqLiteDatabase = favouriteDBHelper.getWritableDatabase();
            result = sqLiteDatabase.delete(FavouriteContract.FavouriteContractEntry.TABLE_NAME, FavouriteContract.FavouriteContractEntry.COLUMN_ID + "=" + Integer.parseInt(selection), null);
            getContext().getContentResolver().notifyChange(uri, null);
        } else {
            throw new UnsupportedOperationException("Not yet implemented");
        }
        return (int) result;
    }

    @Override
    public String getType(Uri uri) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        Uri returnUri = null;
        int match = myuri.match(uri);
        sqLiteDatabase = favouriteDBHelper.getWritableDatabase();
        if (match == FavouriteContract.ROW_ID) {
            long id = sqLiteDatabase.insert(FavouriteContract.FavouriteContractEntry.TABLE_NAME, null, values);
        } else {
            throw new UnsupportedOperationException("Unknown URI" + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return returnUri;
    }

    @Override
    public boolean onCreate() {
        Context context = getContext();
        favouriteDBHelper = new FavouriteDBHelper(context);
        return true;
    }

    public static UriMatcher matchUri() {
        UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(FavouriteContract.AUTH, FavouriteContract.PATH, FavouriteContract.ROW_ID);
        uriMatcher.addURI(FavouriteContract.AUTH, FavouriteContract.PATH + "/#", FavouriteContract.TASK_ID);
        return uriMatcher;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        sqLiteDatabase = favouriteDBHelper.getReadableDatabase();
        int match = myuri.match(uri);
        Cursor result = null;
        if (match == FavouriteContract.ROW_ID) {
            result = sqLiteDatabase.query(FavouriteContract.FavouriteContractEntry.TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
        }
        if (match == FavouriteContract.TASK_ID) {
            int id = Integer.parseInt(uri.getPathSegments().get(1));
            String mSelection = "id=?";
            String[] mSelectionArgs = new String[]{"" + id};
            result = sqLiteDatabase.query(FavouriteContract.FavouriteContractEntry.TABLE_NAME, projection, mSelection, mSelectionArgs, null, null, sortOrder);
        }
        result.setNotificationUri(getContext().getContentResolver(), uri);
        return result;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
