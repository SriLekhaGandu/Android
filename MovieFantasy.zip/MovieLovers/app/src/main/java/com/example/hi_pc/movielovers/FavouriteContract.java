package com.example.hi_pc.movielovers;

import android.net.Uri;
import android.provider.BaseColumns;


public class FavouriteContract {

    public static final String AUTH = "com.example.hi_pc.movielovers";
    public static final Uri BASE_URI = Uri.parse("content://" + AUTH);
    public static final String PATH = "MovieDetails";
    public static final int ROW_ID = 50;
    public static final int TASK_ID = 100;
    public static final Uri CONTENT_URI = BASE_URI.buildUpon().appendPath(PATH).build();

    public class FavouriteContractEntry implements BaseColumns {
        public static final String TABLE_NAME = "MovieDetails";
        public static final String COLUMN_ID = "ID";
        public static final String COLUMN_TITLE = "Title";
        public static final String COLUMN_FAVOURITE = "Checked";
        public static final String COLUMN_BACKDROP_PATH = "Backdrop_path";
        public static final String COLUMN_POSTER_PATH = "Poster_path";
        public static final String COLUMN_RATING = "Rating";
        public static final String COLUMN_VOTES = "Votes";
        public static final String COLUMN_RELEASE_DATE = "Release_date";
        public static final String COLUMN_LANGUAGE = "Language";
        public static final String COLUMN_OVERVIEW = "Overview";
    }
}
