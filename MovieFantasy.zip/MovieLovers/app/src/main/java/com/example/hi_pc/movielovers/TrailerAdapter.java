package com.example.hi_pc.movielovers;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class TrailerAdapter extends RecyclerView.Adapter<TrailerAdapter.TrailerHolder> {
    ArrayList<JSONTrailer> jsontrailer;
    Context context;

    public TrailerAdapter(Context context, ArrayList<JSONTrailer> jsonTrailerList) {
        this.jsontrailer = jsonTrailerList;
        this.context = context;
    }

    @Override
    public TrailerAdapter.TrailerHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.trailler_recycler, parent, false);
        return new TrailerHolder(v);
    }

    @Override
    public void onBindViewHolder(TrailerAdapter.TrailerHolder holder, int position) {
        if (jsontrailer.size() > 0)
            holder.tv.setText(jsontrailer.get(position).getTrailer_name());
    }

    @Override
    public int getItemCount() {
        return jsontrailer.size();
    }

    public class TrailerHolder extends RecyclerView.ViewHolder {
        TextView tv, tr;
        ImageView iv;

        public TrailerHolder(View itemView) {
            super(itemView);
            tv = (TextView) itemView.findViewById(R.id.recycler_trailer_view);
            tr = (TextView) itemView.findViewById(R.id.tr);
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Uri uri = Uri.parse(jsontrailer.get(getAdapterPosition()).getTrailer_url());
                    Intent it = new Intent(Intent.ACTION_VIEW, uri);
                    context.startActivity(it);

                }
            });
            iv = (ImageView) itemView.findViewById(R.id.play_video);
            iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Uri uri = Uri.parse(jsontrailer.get(getAdapterPosition()).getTrailer_url());
                    Intent it = new Intent(Intent.ACTION_VIEW, uri);
                    context.startActivity(it);

                }
            });
        }
    }
}
